# bayareadisaster

Bay area disaster tracker at https://bayareadisastertracking.netlify.app/
